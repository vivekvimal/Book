case class NyseHeader(symbol:String,fullName:String,sector:String)
