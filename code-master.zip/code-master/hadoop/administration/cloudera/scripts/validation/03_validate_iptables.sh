./main.sh ${1} "chkconfig --list iptables"
