./main.sh ${1} "hostname -f"
